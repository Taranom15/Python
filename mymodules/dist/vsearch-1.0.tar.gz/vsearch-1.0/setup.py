from setuptools import setup
setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='MV',
    author_email='taranom15@gmail.com',
    url='',
    py_modules=['vsearch'],
)